public class main {

    public static void main(String[] noseusa) {
        // hard-codear vectores
        //double sales[]= {651,762,856,1063,1190,1298,1421,1440,1518};
        //double advertising[]= {23,26,30,34,43,48,52,57,58};
        double[] sales = {651,762,856,1063,1190,1298,1421,1440,1518};
        double[] advertising = {23,26,30,34,43,48,52,57,58};
        double[] years = {1,2,3,4,5,6,7,8,9};


        //{10.1,1.2},{12.6, 2.8},{14.8,7.6},{16.0,12.8},{17.5,15.1}

        // instanciar un objeto tipo Simple Linear Regression (SLR)
        SLR slr = new SLR();
        double beta0 = 0, beta1 = 0, beta2 = 0;


        // calcular parámetros del model b0 y b1
        beta1 = slr.calculateB1(sales, advertising);
        beta0 = slr.calculateB0(sales, advertising);
        slr.displayRegEq();
        slr.predict(60);

        System.out.println("\n");
        beta2 = slr.calculateB2(sales,advertising,years);
        slr.displayRegNo();

    }
}