import java.lang.Math;

public class VectorOperations {
    Vector v;

    public VectorOperations(Vector theVector) {
        v = theVector;

    }

    public double calculateMagnitude(Vector v1) {
        return Math.sqrt(Math.pow(v.getXValue(), 2) + Math.pow(v.getYValue(), 2) + Math.pow(v.getZValue(), 2));
    }

    public double calculateMagnitudeR2(Vector v1) {
        return Math.sqrt(Math.pow(v.getXValue(), 2) + Math.pow(v.getYValue(), 2));
    }


    public String addVectors(Vector v1, Vector v2) {
        double totalX = v1.getXValue() + v2.getXValue();
        double totalY = v2.getYValue() + v2.getYValue();
        double totalZ = v1.getZValue() + v2.getZValue();
        String vectorResultante;

        vectorResultante = totalX + "i +" + totalY + "j +" + totalZ + "k";

        return vectorResultante;
    }

    public String sumarvr2(Vector v1,Vector v2){
        double totalX = v1.getXValue() + v2.getXValue();
        double totalY = v1.getXValue() + v2.getYValue();
        double totalz = v1.getXValue() + v1.getXValue() + v2.getYValue() + v2.getYValue();
        String vectorResultante;
    vectorResultante = totalX + "i +" + totalY + "j " ;
    return vectorResultante;
    }

    public String sumarvr3(Vector v1, Vector v2){
        double totalX =  v1.getXValue() + v2.getXValue();
        double totalY =  v1.getYValue() + v2.getYValue();
        double totalZ =  v1.getZValue() + v2.getZValue();
        String vectorResultante;
    vectorResultante = totalX + "i +" + totalY + "j +" +totalZ + "k";
    return vectorResultante;
    }

    public String restarvr2(Vector v1,Vector v2){
        double totalX = v1.getXValue() - v2.getXValue();
        double totalY = v1.getXValue() - v2.getYValue();
        double totalz = v1.getXValue() - v1.getXValue() - v2.getYValue() - v2.getYValue();
        String vectorResultante;
    vectorResultante = totalX + "i +" + totalY + "j " ;
    return vectorResultante;
    }

    public String multiplicarEpVr2(Vector v1){
        double totalX = v1.getXValue() * Main.escalar;
        double totalY = v1.getYValue() * Main.escalar;
        String vectorResultante;
    vectorResultante = totalX + "i +" + totalY + "j ";
    return vectorResultante;
    }

    public String multiplicarEpVr3(Vector v1){
        double totalX = v1.getXValue() * Main.escalar;
        double totalY = v1.getYValue() * Main.escalar;
        double totalZ = v1.getZValue() * Main.escalar;
        String vectorResultante;
    vectorResultante = totalX + "i +" + totalY + "j "+ totalZ + "k";
    return vectorResultante;
    }

    public String operacionesAnidadas(Vector v1,Vector v2, Vector v3){
        double totalX = ((4*(2*v1.getXValue()+3* v2.getXValue()))-(v3.getXValue()+ v2.getXValue()));
        double totalY = ((4*(2*v1.getYValue()+3* v2.getYValue()))-(v3.getYValue()+ v2.getYValue()));
        double totalZ = ((4*(2*v1.getZValue()+3* v2.getZValue()))-(v3.getZValue()+ v2.getZValue()));
        String vectorResultante;
        vectorResultante = totalX + "i +" + totalY + "j "+ totalZ + "k";
    return vectorResultante;
    }



}
