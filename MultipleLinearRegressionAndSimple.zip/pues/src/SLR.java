import java.text.DecimalFormat;

public class SLR {
    private double beta0;
    private double beta1;
    private double beta2;



    SLR() {
        beta0 = 0;
        beta1 = 0;

    }
    // calcular B1,  parámetro del modelo SLR
    public double calculateB1(double[] vectorSales, double[] vectorAdvertising) {
        int n=9;
        double sumatoria;
        double sumx=0;
        double sumy=0;
        double sumatoria2=0;
        double sumxc=0;

        for(int i=0;i<n;i++) {
            sumx+=vectorAdvertising[i];
            sumy+=vectorSales[i];
            sumatoria2+= vectorSales[i]*vectorAdvertising[i];
            sumxc+=Math.pow(vectorAdvertising[i],2);

        }
        sumatoria=sumx*sumy;
        beta1=((n*sumatoria2)-sumatoria)/((n*sumxc)-(Math.pow(sumx,2)));
        return beta1;
    }
    // calcular B0,  parámetro del modelo SLR
    public double calculateB0(double[] vectorSales, double[]  vectorAdvertising) {
        int n=9;
        double sumx=0;
        double sumy=0;
        for(int i=0;i<n;i++) {
            sumx+=vectorAdvertising[i];
            sumy+=vectorSales[i];
        }
        //beta0 = 0;// aquí se codifica el modelo matemático construido en clase para B0
        beta0=(sumy-(beta1*sumx))/n;
        return beta0;
    }
    // imprimir ecuación de regresión
    public void displayRegEq() {
        System.out.println("sales =  " + beta0 + " + " + beta1 +  " advertising");
    }
    // predicir ventas en función a un valor dado de advertising
    public void predict(double advertising) {
        double sales = 0;
        sales = beta0 + (beta1 * advertising);
        System.out.println("Dado el valor de advertsing: " + advertising + " las ventas predicidas son = " + sales);
    }


    public double calculateB2(double[] vectorSales, double[] vectorAdvertising,double[] Years) {
        int n=9;
        double sumatoria;
        double sumx2=0;
        double sumy=0;
        double sumx1=0;
        double ds=0;
        double dx=0;
        double dy=0;
        double dz=0;
        double Ex2x1=0;
        double Ex1y=0;
        double Ex2y=0;
        double b0,b1,b2;

        for(int i=0;i<n;i++) {
            sumx2+=vectorAdvertising[i];
            sumy+=vectorSales[i];
            sumx1+=Years[i];
            Ex2x1+=vectorAdvertising[i]*Years[i];
            Ex2y+=vectorAdvertising[i]*vectorSales[i];
            Ex1y+=Years[i]*vectorSales[i];
        }
        ds=((n*Math.pow(sumx1,2)*Math.pow(sumx2,2))+(sumx1*Ex2x1*sumx2)+(sumx2*sumx1*Ex2x1)-(sumx2*Math.pow(sumx1,2)*sumx2)-(Ex2x1*Ex2x1*n)-(Math.pow(sumx2,2)*sumx1*sumx1));
        ds=ds;//determinante del sistema
        dx=((sumy*Math.pow(sumx1,2)*Math.pow(sumx2,2))+(sumx1*Ex2x1*Ex2y)+(sumx2*Ex1y*Ex2x1)-(Ex2y*Math.pow(sumx1,2)*sumx2)-(Ex2x1*Ex2x1*sumy)-(Math.pow(sumx2,2)*Ex1y*sumx1));
        b0=dx/ds;//beta0
        dy=((n*Ex1y*Math.pow(sumx2,2))+(sumy*Ex2x1*sumx2)+(sumx2*sumx1*Ex2y)-(sumx2*Ex1y*sumx2)-(Ex2y*Ex2x1*n)-(Math.pow(sumx2,2)*sumx1*sumy));
        b1=dy/ds;//beta1
        dz=((n*Math.pow(sumx1,2)*Ex2y)+(sumx1*Ex1y*sumx2)+(sumy*sumx1*Ex2x1)-(sumx2*Math.pow(sumx1,2)*sumy)-(Ex2x1*Ex1y*n)-(Ex2y*sumx1*sumx1));
        b2=dz/ds;//beta2
        System.out.println(ds);
        System.out.println(dx);
        beta1=b1;
        beta2=b2;
        beta0=b0;

        return beta0;
    }
    public void displayRegNo() {
        System.out.println("Beta0 =  " + beta0 + " Beta1= " + beta1 +  " Beta2= "+beta2);
    }
}