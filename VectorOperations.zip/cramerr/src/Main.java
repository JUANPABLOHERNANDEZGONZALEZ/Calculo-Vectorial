public class Main {

    public static int escalar=2;
    public static void main(String []args){

        Vector v=new Vector(5,2,7);
        Vector v2=new Vector(2,3,2);
        Vector v3=new Vector(4,3,2);
        VectorOperations operations = new VectorOperations(v);

        System.out.println(operations.calculateMagnitudeR2(v));
        System.out.println(operations.calculateMagnitude(v));
        System.out.println(operations.addVectors(v,v2));
        System.out.println(operations.sumarvr2(v,v2));
        System.out.println(operations.sumarvr3(v,v2));
        System.out.println(operations.restarvr2(v,v2));
        System.out.println(operations.multiplicarEpVr2(v));
        System.out.println(operations.multiplicarEpVr3(v));
        System.out.println(operations.operacionesAnidadas(v,v2,v3));

    }
}
