public class menuR3 {
    public static void main(String[] args) {
        //double[] sales = {1,2,3,4,5,6,7,8,9};
        //double[] advertising = {2,4,6,8,10,12,14,16,18};
        double[] sales = {651,762,856,1063,1190,1298,1421,1440,1518};
        double[] advertising = {23,26,30,34,43,48,52,57,58};
        double[] years = {1,2,3,4,5,6,7,8,9};
        double B0=0,B1=0,B2=0,alfa=0.0003,loss = 1,DPB0=0,DPB1=0,DPB2=0,n=9;
        for(int i=0;i<n;i++)loss+=Math.pow((sales[i]-(B0+(B1*years[i])+(B2*advertising[i]))),2);
        loss=(1/n)*loss;
        System.out.println(loss);
        while(loss>0.001){
            for(int i=0;i<n;i++)DPB0+=(sales[i]-(B0+(B1*years[i])+(B2*advertising[i])));
            DPB0=(-2/n)*DPB0;
            for(int i=0;i<n;i++)DPB1+=(sales[i]-(B0+(B1*years[i])+(B2*advertising[i])))*years[i];
            DPB1=(-2/n)*DPB1;
            for(int i=0;i<n;i++)DPB2+=(sales[i]-(B0+(B1*years[i])+(B2*advertising[i])))*advertising[i];
            DPB2=(-2/n)*DPB2;
            B0=B0-(alfa*DPB0);
            B1=B1-(alfa*DPB1);
            B2=B2-(alfa*DPB2);
            //System.out.println(B0);
            //System.out.println(B1);
            //System.out.println(B2);
            for(int i=0;i<n;i++)loss+=Math.pow((sales[i]-(B0+(B1*years[i])+(B2*advertising[i]))),2);
            loss=(1/n)*loss;
            System.out.println(loss);
        }
        System.out.println("B0 =  " + B0  +  " B1= "+ B1 +" B2= " + B2 + " loss= "+loss);
    }
}
