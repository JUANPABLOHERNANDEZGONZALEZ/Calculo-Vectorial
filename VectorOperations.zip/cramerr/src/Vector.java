public class Vector {

    private double x;
    private double y;
    private double z;

    public Vector(double X, double Y, double Z){

        this.x = X;
        this.y = Y;
        this.z = Z;
    }
    public double getXValue(){
        return x;
    }
    public double getYValue(){
        return y;
    }
    public double getZValue(){
        return z;
    }

}
